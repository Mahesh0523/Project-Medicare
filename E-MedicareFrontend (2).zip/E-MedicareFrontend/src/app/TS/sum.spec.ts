import { Sum } from './sum';

describe('Sum', () => {
  it('should create an instance', () => {
    expect(new Sum()).toBeTruthy();
  });
});
