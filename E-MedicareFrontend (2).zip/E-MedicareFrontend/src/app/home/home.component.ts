import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { NavigationService } from '../navigation.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router:Router, private navigationService: NavigationService) { }

  ngOnInit(): void {
    this.navigationService.setLoggedIn(false);
  }

  gotoregister(){
    this.router.navigate(['/register'])
  }

  signin(){
    this.router.navigate(['/login'])
  }

  adminhome(){
    this.router.navigate(['/adminhome'])
  }

  customerdashboard(){
    this.navigationService.setLoggedIn(true);
    this.router.navigate(['/customerdashboard'])
  }

  csignin(){
    this.router.navigate(['/customerlogin'])
  }
}
